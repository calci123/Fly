<?php

namespace calci123;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use pocketmine\Player;

class Main extends PluginBase implements Listener{

public $flyList = [];

public function onEnable(){
$this->getServer()->getPluginManager()->registerEvents($this, $this);
}

public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{

switch($cmd->getName()){

case "fly":

if($sender instanceof Player){
if($sender->hasPermission("fly.cmd")){
if(!isset($this->flyList[$sender->getName()])){

$this->flyList[$sender->getName()] = $sender->getName();

$sender->setFlying(true);
$sender->setAllowFlight(true);

$sender->sendMessage("§aUçuş modu aktif.");
}else{

unset($this->flyList[$sender->getName()]);

$sender->setFlying(false);
$sender->setAllowFlight(false);

$sender->sendMessage("§cUçuş modu deaktif.");
}
}
}
break;
}
return true;
}
}